@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center text-center">
        <div class="col-12 display-4">Hello {{Auth::user()->name}}</div>
        <div class="col-12 display-4">This will be your Dashboard place</div>
        <div class="col-12 display-2">&</div>
        <div class="col-12 display-4">where all your dream starts</div>
    </div>
</div>
@endsection